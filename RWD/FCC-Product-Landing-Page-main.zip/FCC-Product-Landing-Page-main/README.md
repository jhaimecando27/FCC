># FCC:Product Landing Page
* A responsive web design project for [Free Code Camp](https://www.freecodecamp.org/).  
  
***
>## Status
* Done.  

***
>### Link:
* For the Website open [[here]](https://jhaimecando27.github.io/FCC-Product-Landing-Page/) 
* For the Codepen open [[here]](https://codepen.io/jhaimecando27/full/oNzJgNZ)

***
>#### Note:
* Just a new user playing around GitHub. If you have tips or suggestions, I'm willing to listen. hehe  
* Contact me in my E-mail [[here]](jhaimecando27@gmail.com)  

***
># <span>This is for educational purposes only!</span>
