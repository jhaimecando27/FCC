># FCC: Technical Documentation Page
* A responsive web design project for [Free Code Camp](https://www.freecodecamp.org/).  
  
***
>## Status
* Done.  

***
>### Link:
* CodePen [[here]](https://codepen.io/jhaimecando27/full/PoGVgQR)

***
>#### Note:
* Just a new user playing around GitHub. If you have tips or suggestions, I'm willing to listen. hehe  
* Contact me in my E-mail [[here]](jhaimecando27@gmail.com)  

***
># <span>This is for educational purposes only!</span>
